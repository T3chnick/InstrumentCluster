#include <Fonts/Font72rle.c>

#define nr_chrs_f72 96
#define chr_hgt_f72 75
#define baseline_f72 73
#define data_size_f72 8
#define firstchr_f72 32

extern const unsigned char widtbl_f72[96];
extern const unsigned char* const chrtbl_f72[96];
